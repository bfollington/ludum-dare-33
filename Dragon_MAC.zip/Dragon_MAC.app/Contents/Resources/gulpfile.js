var watch = require('gulp-watch');
var gulp = require('gulp');
var shell = require('gulp-shell');

gulp.task("assets", function()
{
    gulp.src("")
        .pipe(shell("cd assets/; python directory.py"));
});

gulp.task("entities", function()
{
    gulp.src("")
        .pipe(shell("cd entities/loadable/; python generate.py"));
});

gulp.task("watch", ['assets', 'entities'], function()
{
    watch(["assets/**/*.{png,oel,xml,mp3}"], function() {
        gulp.start("assets");
    });

    watch(["entities/loadable/**.as", "!entities/loadable/E.as"], function() {
        gulp.start("entities");
    });
});
